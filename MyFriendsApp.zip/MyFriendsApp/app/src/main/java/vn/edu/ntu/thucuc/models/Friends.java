package vn.edu.ntu.thucuc.models;

public class Friends {
    String id, name, ngaysinh, sdt, diachi;

    public Friends(String id, String name, String ngaysinh, String sdt, String diachi) {
        this.id = id;
        this.name = name;
        this.ngaysinh = ngaysinh;
        this.sdt = sdt;
        this.diachi = diachi;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNgaysinh() {
        return ngaysinh;
    }

    public void setNgaysinh(String ngaysinh) {
        this.ngaysinh = ngaysinh;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getDiachi() {
        return diachi;
    }

    public void setDiachi(String diachi) {
        this.diachi = diachi;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    @Override
    public String toString() {
        return name;
    }
}
