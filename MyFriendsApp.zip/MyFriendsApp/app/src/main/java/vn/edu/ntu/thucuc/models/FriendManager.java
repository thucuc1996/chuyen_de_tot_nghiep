package vn.edu.ntu.thucuc.models;

import java.util.ArrayList;

public class FriendManager {
    ArrayList<Friends> friends ;
    private static FriendManager manager;

    private FriendManager() {
        friends = new ArrayList<>();
        friends.add(new Friends("01", "Nhật Minh", "1/1/1996", "038999123", "Nha Trang"));
        friends.add(new Friends("02", "Hoàng Hiếu", "2/1/1991", "035999123", "Đà nẵng"));
        friends.add(new Friends("03", "Linh Chi", "1/3/1994", "038999123", "TP HCM"));
        friends.add(new Friends("04", "Huy Hoàng", "3/1/1993", "034999123", "Nha Trang"));
        friends.add(new Friends("05", "Gia Bảo", "1/9/1997", "032999123", "Vũng Tàu"));
        friends.add(new Friends("06", "Minh Nhi", "11/1/1992", "031999123", "Phú Yên"));
    }
    public static FriendManager getInstance(){
        if ((manager == null))
            manager = new FriendManager();
        return manager;
    }

    public ArrayList<Friends> getFriends() {
        return friends;
    }
}
