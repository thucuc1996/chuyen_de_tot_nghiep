package vn.edu.ntu.thucuc.myfriendsapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import vn.edu.ntu.thucuc.models.FriendManager;
import vn.edu.ntu.thucuc.models.Friends;

public class MainActivity extends AppCompatActivity {
    ListView lvFriends;
    //ArrayList<Friends> listResult;
    ArrayAdapter <Friends> adapter;
    FloatingActionButton fab;
     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

         fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        addContentView();
        addEvents();
    }

    private void addEvents() {
         lvFriends.setOnItemClickListener(new AdapterView.OnItemClickListener() {
             @Override
             public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                 XuLyClick_LV_Item(position);
                 fab.setOnClickListener(new View.OnClickListener() {
                     @Override
                     public void onClick(View view) {
                         XuLyManHinh2();
                     }
                 });
             }
         });
    }

    private void XuLyManHinh2() {
        Intent intent = new Intent(this, FriendAddActivity.class);
        startActivity(intent);
    }

    private void XuLyClick_LV_Item(int position) {
         int size = FriendManager.getInstance().getFriends().size();
         if ((position >= 0 && position <size)){
             String str = FriendManager.getInstance().getFriends().get(position).toString();
             Toast.makeText(this,str,Toast.LENGTH_SHORT).show();
         }

    }

    private void addContentView() {
         fab = findViewById(R.id.fab);
         lvFriends = findViewById(R.id.lvFriends);
         adapter = new ArrayAdapter<>(this,
                 android.R.layout.simple_list_item_1,
                 FriendManager.getInstance().getFriends());
         lvFriends.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
