package vn.edu.ntu.thucuc.myfriendsapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class FriendAddActivity extends AppCompatActivity implements View.OnClickListener {
    EditText edtId, edtTen, edtNgaySinh, edtDiaChi, edtSDT;
    Button btnSave, btnCancel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_add);
        addContentView();
        addEvents();
    }

    private void addEvents() {
        btnSave.setOnClickListener(this);
        btnCancel.setOnClickListener(this);
    }

    private void addContentView() {
        edtId = findViewById(R.id.edit_id);
        edtTen = findViewById(R.id.edit_ten);
        edtNgaySinh = findViewById(R.id.edit_ngaysinh);
        edtDiaChi = findViewById(R.id.edit_diachi);
        edtSDT = findViewById(R.id.edit_sdt);
        btnSave = findViewById(R.id.label_btn_save);
        btnCancel = findViewById(R.id.label_btn_cancel);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() ==R.id.label_btn_save)
        {
            xuLyLuu();
        }
        else
        if(v.getId() == R.id.label_btn_cancel)
        {
            xuLyHuy();
        }
    }

    private void xuLyHuy() {
        setResult(RESULT_CANCELED);
        finish();;
    }

    private void xuLyLuu() {

    }

}
