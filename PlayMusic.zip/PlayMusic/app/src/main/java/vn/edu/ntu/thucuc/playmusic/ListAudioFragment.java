package vn.edu.ntu.thucuc.playmusic;


import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;

import vn.edu.ntu.thucuc.playmusic.model.MyAudio;
import vn.edu.ntu.thucuc.playmusic.model.MyAudioUtil;


/**
 * A simple {@link Fragment} subclass.
 */
public class ListAudioFragment extends Fragment {

    RecyclerView rvListAudio;
    AudioAdapter adapter;
    MediaPlayer mediaPlayer;
    ArrayList<MyAudio> listAudio;
    public ListAudioFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_list_audio, container, false);
        rvListAudio = view.findViewById(R.id.rvListAudio);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 1);
        rvListAudio.setLayoutManager(gridLayoutManager);
        listAudio = MyAudioUtil.loadAudio(getContext());
        return  view;

    }
    //inner classes
    private  class AudioViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
         MyAudio item;
         TextView txtTitle, txtArtist;
         View audioContainer;
        public AudioViewHolder(@NonNull View itemView) {
            super(itemView);
            txtTitle = this.itemView.findViewById(R.id.txtTitle);
            txtArtist = this.itemView.findViewById(R.id.txtArtist);
            audioContainer = this.itemView.findViewById(R.id.item_audio_container);
            audioContainer.setOnClickListener(this);
        }
        public  void onBind( MyAudio item){
            this.item = item;
            txtTitle.setText(item.getTitle());
            txtArtist.setText(item.getArtist());
        }

        @Override
        public void onClick(View v) {
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying())
                    mediaPlayer.stop();
                    mediaPlayer.release();
                    mediaPlayer = null;
            }
            mediaPlayer = new MediaPlayer();
            try {
                mediaPlayer.setDataSource(this.item.getData());
                mediaPlayer.prepare();
                mediaPlayer.start();
            }catch (IOException e){
                e.printStackTrace();
            }

        }
    }
private  class AudioAdapter extends  RecyclerView.Adapter<AudioViewHolder>{
        ArrayList<MyAudio> list;

    public AudioAdapter(ArrayList<MyAudio> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public AudioViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View view = inflater.inflate(R.layout.item_audio, viewGroup, false);
        return  new AudioViewHolder(view);
        //return null;
    }

    @Override
    public void onBindViewHolder(@NonNull AudioViewHolder audioViewHolder, int i)
    {
        audioViewHolder.onBind(list.get(i));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
}
